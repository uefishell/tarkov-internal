#ifndef CUSTOM_STRUCTS_HPP
#define CUSTOM_STRUCTS_HPP

#include "sdk_extra/custom/iplayer.hpp"

#include <array>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace mono {
    class mono_object;
}

namespace eft {
    class player_interface;
    enum class e_member_category;
    namespace next_observed_player {
        class observed_player_view;
    }
    namespace inventory_logic {
        class item;
        enum class equipment_slot;
    }

    namespace quests {
        enum class e_quest_type;
    }

    // https://www.unknowncheats.me/forum/2282157-post609.html
    enum bone_id : int32_t {
        human_base = 0,
        human_pelvis = 14,
        human_left_thigh1 = 15,
        human_left_thigh2 = 16,
        human_left_calf = 17,
        human_left_foot = 18,
        human_left_toe = 19,
        human_right_thigh1 = 20,
        human_right_thigh2 = 21,
        human_right_calf = 22,
        human_right_foot = 23,
        human_right_toe = 24,
        human_spine1 = 29,
        human_spine2 = 36,
        human_spine3 = 37,
        human_left_collarbone = 89,
        human_left_upperarm = 90,
        human_left_forearm1 = 91,
        human_left_forearm2 = 92,
        human_left_forearm3 = 93,
        human_left_palm = 94,
        human_right_collarbone = 110,
        human_right_upperarm = 111,
        human_right_forearm1 = 112,
        human_right_forearm2 = 113,
        human_right_forearm3 = 114,
        human_right_palm = 115,
        human_neck = 132,
        human_head = 133
    };

    constexpr std::array<bone_id, 28> target_bones = {
        human_left_foot,
        human_left_toe,
        human_right_foot,
        human_right_toe,
        human_right_calf,
        human_left_calf,
        human_right_thigh1,
        human_right_thigh2,
        human_left_thigh1,
        human_left_thigh2,
        human_right_palm,
        human_left_palm,
        human_right_forearm1,
        human_right_forearm2,
        human_right_forearm3,
        human_left_forearm1,
        human_left_forearm2,
        human_left_forearm3,
        human_right_upperarm,
        human_left_upperarm,
        human_pelvis,
        human_spine1,
        human_spine2,
        human_spine3,
        human_left_collarbone,
        human_right_collarbone,
        human_neck,
        human_head};

    constexpr std::pair<bone_id, bone_id> skeleton_connections[] = {
        {human_head, human_neck},
        {human_spine3, human_neck},
        {human_spine3, human_spine2},
        {human_spine2, human_spine1},
        {human_left_forearm1, human_neck},
        {human_right_forearm1, human_neck},
        {human_left_forearm2, human_left_forearm1},
        {human_right_forearm2, human_right_forearm1},
        {human_right_forearm3, human_right_forearm2},
        {human_left_forearm3, human_left_forearm2},
        {human_left_palm, human_left_forearm3},
        {human_right_palm, human_right_forearm3},
        {human_spine1, human_right_thigh2},
        {human_spine1, human_left_thigh2},
        {human_right_thigh2, human_right_calf},
        {human_left_thigh2, human_left_calf},
        {human_right_calf, human_right_foot},
        {human_left_calf, human_left_foot},
        {human_right_foot, human_right_toe},
        {human_left_foot, human_left_toe}};
}

enum aimbot_target_selection_type : int32_t {
    target_selection_fov,
    target_selection_distance,
    target_selection_health
};

enum aimbot_target_bone : int32_t {
    target_head,
    target_thorax,
    target_arms,
    target_legs
};

enum box_type : int32_t {
    box_none,
    box_2d,
    box_2d_corner,
    box_3d,
    box_3d_corner
};

enum cham_material_type : int32_t {
    material_flat,
    material_force_field,
    material_wireframe
};

enum tracer_render_type : int32_t {
    tracers_render_line,
    tracers_render_trail // Use UnityEngine.TrailRenderer
};

enum trail_tracer_texture_type : int32_t {
    trail_texture_beam,
    trail_texture_laser,
    trail_texture_lightning
};

enum hit_indicator : int32_t {
    hit_indicator_none,
    hit_indicator_2d, // 2d centered hitmarker
    hit_indicator_3d, // 2d hitmarker positioned in 3d space
    hit_indicator_3d_normal // 2d hitmarker aligned on the hit_normal
};

enum hit_marker_sound : int32_t {
    hit_marker_boom,
    hit_marker_cod,
    hit_marker_hitsound,
    hit_marker_metal,
    hit_marker_punch,
    hit_marker_qbeep,
    hit_marker_roblox,
    hit_marker_skeet
};

enum speed_hack_mode : int32_t {
    speed_hack_timescale,
    speed_hack_flash,
    speed_hack_transform,
    speed_hack_direct
};

enum player_stance : int32_t {
    standing,
    prone,
    transit2prone
};

enum visibility : int32_t {
    hidden,
    can_penetrate,
    visible
};

// https://db.sp-tarkov.com/search/55d7217a4bdc2d86028b456d
constexpr std::array<const wchar_t*, 15> slot_names {
    L"FirstPrimaryWeapon",
    L"SecondPrimaryWeapon",
    L"Holster",
    L"Scabbard",
    L"Backpack",
    L"SecuredContainer",
    L"TacticalVest",
    L"ArmorVest",
    L"Pockets",
    L"Eyewear",
    L"FaceCover",
    L"Headwear",
    L"Earpiece",
    L"Dogtag",
    L"ArmBand"
};

constexpr std::array<std::pair<const char*, eft::bone_id>, 4> target_bones {
    std::pair<const char*, eft::bone_id>{"Head", eft::human_head},
    std::pair<const char*, eft::bone_id>{"Thorax", eft::human_spine3},
    std::pair<const char*, eft::bone_id>{"Legs", eft::human_left_thigh2},
    std::pair<const char*, eft::bone_id>{"Arms", eft::human_left_upperarm}
};

constexpr std::array<std::pair<const char*, eft::e_player_state>, 3> resolver_state {
    std::pair<const char*, eft::e_player_state>{"Standing", eft::e_player_state::idle},
    std::pair<const char*, eft::e_player_state>{"Prone", eft::e_player_state::prone_idle},
    std::pair<const char*, eft::e_player_state>{"Transit to prone", eft::e_player_state::transit2prone}
};

constexpr std::array<std::pair<const char*, int32_t>, 2> tracer_render_types {
    std::pair<const char*, int32_t>{"Line", tracers_render_line},
    std::pair<const char*, int32_t>{"Trail", tracers_render_trail}
};

constexpr std::array<std::pair<const char*, int32_t>, 2> trail_tracer_texture_types {
    std::pair<const char*, int32_t>{"Beam", trail_texture_beam},
    std::pair<const char*, int32_t>{"Laser", trail_texture_laser}
};

constexpr std::array<std::pair<const char*, int32_t>, 4> hit_marker_types {
    std::pair<const char*, int32_t>{"None", hit_indicator_none},
    std::pair<const char*, int32_t>{"2D", hit_indicator_2d},
    std::pair<const char*, int32_t>{"3D", hit_indicator_3d},
    std::pair<const char*, int32_t>{"3D normal", hit_indicator_3d_normal}
};

constexpr std::array<std::pair<const char*, int32_t>, 4> speed_hack_types {
    std::pair<const char*, int32_t>{"Timescale", speed_hack_timescale},
    std::pair<const char*, int32_t>{"Flash", speed_hack_flash},
    std::pair<const char*, int32_t>{"Transform", speed_hack_transform},
    std::pair<const char*, int32_t>{"Direct", speed_hack_direct}
};

constexpr std::array<std::pair<const char*, const wchar_t*>, 3> chams_types {
    std::pair<const char*, const wchar_t*>{"Flat", L"assets/kiwicheats/shaders/flat.shader"},
    std::pair<const char*, const wchar_t*>{"Force field", L"assets/kiwicheats/shaders/force_field.shader"},
    std::pair<const char*, const wchar_t*>{"Wireframe", L"assets/kiwicheats/shaders/wireframe.shader"}
};

// TODO: More hitsounds
constexpr std::array<std::pair<const char*, const wchar_t*>, 8> hit_marker_sounds {
    std::pair<const char*, const wchar_t*>{"Boom", L"assets/kiwicheats/sounds/boom.wav"},
    std::pair<const char*, const wchar_t*>{"COD", L"assets/kiwicheats/sounds/cod.wav"},
    std::pair<const char*, const wchar_t*>{"Hitsound", L"assets/kiwicheats/sounds/hitsound.wav"},
    std::pair<const char*, const wchar_t*>{"Metal", L"assets/kiwicheats/sounds/metal.wav"},
    std::pair<const char*, const wchar_t*>{"Punch", L"assets/kiwicheats/sounds/punch.wav"},
    std::pair<const char*, const wchar_t*>{"QBeep", L"assets/kiwicheats/sounds/qbeep.wav"},
    std::pair<const char*, const wchar_t*>{"Roblox", L"assets/kiwicheats/sounds/roblox.wav"},
    std::pair<const char*, const wchar_t*>{"Skeet", L"assets/kiwicheats/sounds/skeet.wav"}
};

constexpr std::array<const char*, 5> player_box_types = {"None", "2D", "2D corner", "3D", "3D corner"};
constexpr std::array<const char*, 3> aimbot_target_types = {"Field of view", "Distance", "Health"};
constexpr std::array<const char*, 4> aimbot_bone_types = {"Head", "Thorax", "Arms", "Legs"};

namespace game {
    struct cached_player_profile_info {
        int32_t level;
        eft::e_member_category member_category;
        eft::e_player_side side;
    };

    struct cached_player {
        eft::player_interface iplayer;
        std::wstring id;
        std::wstring group_id;
        std::wstring name;
        bool grouped;
        bool oof;

        explicit cached_player(eft::player_interface iplayer);
        cached_player() = delete;
        explicit operator bool() const;
    };

    // Target information
    struct target_info {
        std::shared_ptr<game::cached_player> player {};

        std::unique_ptr<player_held_item_info> held_item_info {};

        bool lock_target {};
        glm::vec3 position {};
        glm::vec3 predicted_position {};
        glm::vec3 velocity_factored_position {};
        glm::vec3 shot_position {};
        glm::vec3 velocity {};
        float drop {};
        float time_to_target {};

        target_info() = default;

        explicit target_info(std::shared_ptr<game::cached_player> player)
        : player(std::move(player))
        {}

        explicit target_info(glm::vec3 position)
        : position(position)
        {}
    };

    // Bullet tracers
    struct tracer {
        float time;
        glm::vec3 start;
        glm::vec3 end;
        eft::ballistics::shot_e_bullet_state state;
    };

    // Hit markers
    struct hit_record {
        float time;
        glm::vec3 position;
        glm::vec3 normal;
        float damage;

        // TODO: Store body part and color depending on fragmentation and inflicted bleeding
    };

    enum loot_rarity : int32_t {
        worthless = (1 << 0),
        common = (1 << 1),
        uncommon = (1 << 2),
        rare = (1 << 3),
        epic = (1 << 4),
        legendary = (1 << 5),
        quest = (1 << 6),
        unknown = (1 << 7),
        user_filter = (1 << 8)
    };

    enum class player_item_flag : int32_t {
        thermal_item,
        key_card,
        grenade_launcher
    };

    struct container_item {
        std::wstring label;
        int32_t rarity;
        int32_t price;
        std::wstring id;
        eft::inventory_logic::item* item;
    };

    struct cached_player_data {
        std::vector<container_item> items;
        std::vector<std::pair<std::wstring, renderer::color_rgba>> effects;
        std::unordered_map<eft::inventory_logic::equipment_slot, std::wstring> equipment;
        int64_t value;

        void cache_player_items(eft::player_interface& iplayer);
        int64_t total_value();
    };

    struct cached_item {
        glm::vec3 position {};
        std::wstring label {};
        std::wstring id {};
        std::vector<container_item> items {};
        int64_t total_value();

        cached_item() = default;
        cached_item(glm::vec3 position, std::wstring label, std::wstring id)
        : position(position)
        , label(std::move(label))
        , id(std::move(id))
        {}
    };

    struct cached_loot_item : cached_item {
        int32_t rarity = loot_rarity::unknown;
        unity_engine::bounds bounds {};
        eft::inventory_logic::item* item;

        cached_loot_item(glm::vec3 position, std::wstring label, std::wstring id, int32_t rarity, unity_engine::bounds bounds)
        : cached_item(position, std::move(label), std::move(id))
        , rarity(rarity)
        , bounds(bounds)
        {}
    };

    struct cached_container : cached_item {
        cached_container() = default;
        cached_container(glm::vec3 position, std::wstring label, std::wstring id, unity_engine::bounds bounds)
            : cached_item(position, std::move(label), std::move(id)), bounds(bounds) {}

        unity_engine::bounds bounds {};
    };

    struct cached_corpse : cached_item {
        cached_corpse() = default;
        cached_corpse(glm::vec3 position, std::wstring label, std::wstring id, bool player)
        : cached_item(position, std::move(label), std::move(id))
        , player(player)
        {}

        bool player = false;
    };

    struct cached_quest_condition {
        std::wstring id;
        std::string name;
        glm::vec3 location;
        std::vector<std::wstring> targets;
        std::wstring description;
        std::wstring parent_id;
        bool current_map;
    };

    struct cached_quest {
        std::wstring id;
        std::wstring name;
        std::wstring location;
        bool current_map;
        eft::quests::quest_template_e_quest_type quest_type;
        std::unique_ptr<std::vector<std::pair<std::wstring, std::wstring>>> required_keys;
        std::unique_ptr<std::vector<cached_quest_condition>> conditions;
    };
}

#endif