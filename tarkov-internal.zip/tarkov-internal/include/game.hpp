#ifndef GAME_HPP
#define GAME_HPP

#include "sdk.hpp"

#include "util.hpp"
#include "market.hpp"
#include "globals.hpp"
#include "custom_structs.hpp"

#include <algorithm>

#include <tracy/Tracy.hpp>

namespace game {
    bool initialize();
    void cleanup();

    void init_assets();
    void apply_chams(unity_engine::material* material, cham_material_type type, renderer::color_rgba visible, renderer::color_rgba hidden);

    std::shared_ptr<cached_player> find_target();
    glm::vec3 get_crosshair_world_pos();
    float fov_to_pixel_distance(float fov_in);

    bool is_offline_raid();
    std::wstring get_location_object_id();
    std::wstring get_location_id();
    std::wstring get_game_time();

    std::unique_ptr<std::tuple<unity_engine::bounds, unity_engine::transform*>> get_scope_properties();
    bool is_within_scope_bounds(const glm::vec3& screen_pos);

    bool can_penetrate(const unity_engine::raycast_hit& hit, const glm::vec3& start);
    bool is_object_hit(const unity_engine::raycast_hit& hit, void* object);
    static visibility default_vis_predicate(const std::vector<unity_engine::raycast_hit>& hits, void* object, const glm::vec3& start) {
        if (object == nullptr && hits.size() == 1)
            return visible;

        auto object_hit = hits.end();

        if (object != nullptr) {
            // Find hit where the object was hit
            object_hit = std::ranges::find_if(hits, [object](const auto& hit) -> bool {
                return is_object_hit(hit, object);
            });

            if (object_hit == hits.end())
                return hidden;
        }

        if (object_hit == hits.begin())
            return visible;

        if (std::all_of(hits.begin(), object_hit, [&start](const auto& hit) -> bool { return can_penetrate(hit, start); }))
            return visibility::can_penetrate;

        return hidden;
    }
    visibility is_visible(void* object, glm::vec3 start, glm::vec3 end, const std::function<visibility (const std::vector<unity_engine::raycast_hit>&, void*, const glm::vec3& start)>& predicate = default_vis_predicate);

    bool in_game();
    void initialize_counters();
    void init_layermasks();
    void raid_cleanup();
    void read_inputs();
    void init_item_data();
    void init_tarkov_locations();
    void fetch_market_data();
    void kd_dropper();

    float find_needed_initial_speed(glm::vec3 start, glm::vec3 end, int32_t layer_mask);
    std::pair<float, float> trajectory_to_target(glm::vec3 start, glm::vec3 end);

    unity_engine::raycast_hit raycast_trajectory(eft::ballistics::trajectory_info* trajectory_info);

    glm::vec3 find_best_origin(void* object, const glm::vec3& origin, const glm::vec3& target, float origin_magnitude = 1);
    glm::vec3 find_best_scale(void* object, const glm::vec3& origin, const glm::vec3& target, float origin_magnitude = 1);

    unity_engine::bounds get_bounds(mono::mono_object* object);
    bool get_bbox(const unity_engine::bounds& bounds, glm::vec4& bbox);

    std::wstring format_price(int64_t price);
    void format_market_item(const std::wstring& id, std::wstring& label, int32_t& rarity, int32_t& price, bool full_name = false);
    void format_ammo_item(eft::inventory_logic::item* item, std::wstring& label);
    bool is_rarity_good(int32_t rarity);
    renderer::color_rgba get_rarity_color(int32_t rarity);
    void sort_items_by_price(std::vector<game::container_item>& items);
    int32_t get_item_rarity(const std::wstring& name, const std::wstring& id, int32_t price, market::item_types type, bool map_quest_item);

    void read_stats(std::wstring id, eft::counters::counter_dictionary* overall_counters);
    void read_profile_info(std::wstring id, eft::network::other_player_profile_info* info);

    void add_item_to_container(std::vector<game::container_item>& container, eft::inventory_logic::item* item);

    void add_grids_to_container(std::vector<game::container_item>& container, dotnet::array<eft::inventory_logic::grid*>* grids, bool player_grids = false, std::wstring_view parent_slot_id = {});
    void add_slots_to_container(std::vector<game::container_item>& container, dotnet::array<eft::inventory_logic::slot*>* slots, bool player_slots = false);

    template <typename T>
    T* get_game_object_instance(const wchar_t* name) {
        const auto game_object_name = mono::string::from_string(name);
        const auto address = memory::read_chain((uint64_t) unity_engine::game_object::find((dotnet::string*) game_object_name), {0x10, 0x30, 0x18});
        if (address == 0)
            return 0;

        return *reinterpret_cast<T**>(address + 0x28);
    }
}

#endif