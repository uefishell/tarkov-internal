#ifndef CACHE_CACHE_HPP
#define CACHE_CACHE_HPP

namespace cache {
    void update_loot();
    void update_players();
    void update_players_data();
    void update_quests();
}

#endif