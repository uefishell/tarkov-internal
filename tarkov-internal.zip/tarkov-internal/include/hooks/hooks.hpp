#ifndef HOOKS_HOOKS_HPP
#define HOOKS_HOOKS_HPP

#include "config.hpp"
#include "sdk.hpp"

#include "util/vmt.hpp"

#include <d3d11.h>
#include <tracy/Tracy.hpp>

#define IMGUI_DEFINE_MATH_OPERATORS
#include <backends/imgui_impl_dx11.h>
#include <backends/imgui_impl_win32.h>
#include <imgui.h>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace hooks {
    bool target_class_initialize();
    bool initialize();
    void cleanup();
    void target_class_cleanup();

    // Swap chain hooks
    extern IDXGISwapChain* find_d3d11_swap_chain();
    extern vmt d3d11_swap_chain_vmt;

    HRESULT swap_chain_present_hk(IDXGISwapChain* swap_chain, uint32_t sync_interval, uint32_t flags);
    inline decltype(&swap_chain_present_hk) swap_chain_present_o;

    HRESULT swap_chain_get_buffer_hk(IDXGISwapChain* swap_chain, UINT buffer, REFIID riid, void** surface);
    inline decltype(&swap_chain_get_buffer_hk) swap_chain_get_buffer_o;

    HRESULT swap_chain_resize_buffers_hk(IDXGISwapChain* swap_chain, uint32_t buffer_count, uint32_t width, uint32_t height,
                                         DXGI_FORMAT new_format, uint32_t swap_chain_flags);
    inline decltype(&swap_chain_resize_buffers_hk) swap_chain_resize_buffers_o;

    // D3D11DeviceContext hooks
    void d3d11_device_context_copy_resource_hk(ID3D11DeviceContext* device_context, ID3D11Resource* destination_resource, ID3D11Resource* source_resource);
    inline decltype(&d3d11_device_context_copy_resource_hk) d3d11_device_context_copy_resource_o;

    void d3d11_device_context_copy_subresource_region_hk(ID3D11DeviceContext* device_context, ID3D11Resource* destination_resource, UINT destination_subresource,
                                                         UINT destination_x, UINT destination_y, UINT destination_z, ID3D11Resource* source_resource,
                                                         UINT source_subresource, const D3D11_BOX* source_box, UINT copy_flags);
    inline decltype(&d3d11_device_context_copy_subresource_region_hk) d3d11_device_context_copy_subresource_region_o;

    bool initialize_or_reset_d3d11_swap_chain_hwnd_hk(HWND__* window, void* repositionrect,
                                                      int screenWidth,
                                                      int screenHeight,
                                                      int renderWidth,
                                                      int renderHeight,
                                                      unsigned int refreshRate,
                                                      bool fullscreen,
                                                      bool stereo,
                                                      unsigned int vsynccount,
                                                      bool hdrDisplay,
                                                      int* outBackbufferBPP,
                                                      int* outFrontbufferBPP,
                                                      int* outDepthBPP);
    inline decltype(&initialize_or_reset_d3d11_swap_chain_hwnd_hk) initialize_or_reset_d3d11_swap_chain_hwnd_o;

    LRESULT wnd_proc_hk(HWND hwnd, uint32_t message, WPARAM wparam, LPARAM lparam);
    inline decltype(&wnd_proc_hk) wnd_proc_o;

    bool mono_add_process_object_hk(mono::mono_object*, void*);
    inline decltype(&mono_add_process_object_hk) mono_add_process_object_o;

    void mono_traverse_gc_desc_hk(mono::mono_object*, void*);
    inline decltype(&mono_traverse_gc_desc_hk) mono_traverse_gc_desc_o;

    void afk_monitor_start_hk(void*);
    inline decltype(&afk_monitor_start_hk) afk_monitor_start_o;

    void target_class_on_gui_hk(void*);
    inline decltype(&target_class_on_gui_hk) target_class_on_gui_o;

    void target_class_update_hk(void*);
    inline decltype(&target_class_update_hk) target_class_update_o;

    void target_class_fixed_update_hk(void*);
    inline decltype(&target_class_fixed_update_hk) target_class_fixed_update_o;

    void target_class_awake_hk(void*);
    inline decltype(&target_class_awake_hk) target_class_awake_o;

    void target_class_start_hk(void*);
    inline decltype(&target_class_start_hk) target_class_start_o;

    void preloader_ui_update_hk(eft::ui::preloader_ui*);
    inline decltype(&preloader_ui_update_hk) preloader_ui_update_o;

    unity_engine::renderer* skin_skinned_mesh_render_hk(diz::skinning::skin*);
    inline decltype(&skin_skinned_mesh_render_hk) skin_skinned_mesh_render_o;

    void client_firearm_controller_initiate_shot_hk(eft::player_firearm_controller*, eft::inventory_logic::item*, eft::inventory_logic::item*, glm::vec3, glm::vec3, glm::vec3, int32_t, float);
    inline decltype(&client_firearm_controller_initiate_shot_hk) client_firearm_controller_initiate_shot_o;

    void firearm_controller_initiate_shot_hk(eft::player_firearm_controller*, eft::inventory_logic::item*, eft::inventory_logic::item*, glm::vec3, glm::vec3, glm::vec3, int32_t, float);
    inline decltype(&firearm_controller_initiate_shot_hk) firearm_controller_initiate_shot_o;

    void camera_manager_set_fov_hk(void*, float, float, bool);
    inline decltype(&camera_manager_set_fov_hk) camera_manager_set_fov_o;

    eft::network::shots_for_approvement* shot_get_shot_info_hk(eft::ballistics::shot* shot);
    inline decltype(&shot_get_shot_info_hk) shot_get_shot_info_o;

    bool shot_bullet_movement_hk(eft::ballistics::shot*, glm::vec3, glm::vec3);
    inline decltype(&shot_bullet_movement_hk) shot_bullet_movement_o;

    void shot_update_hk(eft::ballistics::shot* shot, float delta_time);
    inline decltype(&shot_update_hk) shot_update_o;

    bool inventory_controller_can_start_new_search_operation_hk(eft::inventory_controller* instance);
    inline decltype(&inventory_controller_can_start_new_search_operation_hk) inventory_controller_can_start_new_search_operation_o;

    bool state_is_suitable_for_hand_input_hk(eft::player* instance);
    inline decltype(&state_is_suitable_for_hand_input_hk) state_is_suitable_for_hand_input_o;

    void preloader_ui_set_session_id_hk(eft::ui::preloader_ui* instance, dotnet::string* session_id);
    inline decltype(&preloader_ui_set_session_id_hk) preloader_ui_set_session_id_o;

    bool inventory_controller_checked_magazine_hk(eft::inventory_controller* instance, eft::inventory_logic::magazine_item* magazine_item);
    inline decltype(&inventory_controller_checked_magazine_hk) inventory_controller_checked_magazine_o;

    bool inventory_controller_is_allowed_to_see_slot_hk(eft::inventory_controller* instance, eft::inventory_logic::slot* slot, eft::inventory_logic::equipment_slot slot_name);
    inline decltype(&inventory_controller_is_allowed_to_see_slot_hk) inventory_controller_is_allowed_to_see_slot_o;

    bool can_remove_from_slot_during_raid_hk(void* instance, dotnet::string* equipment_slot_id);
    inline decltype(&can_remove_from_slot_during_raid_hk) can_remove_from_slot_during_raid_o;

    bool can_put_into_hk(void* instance);
    inline decltype(&can_put_into_hk) can_put_into_o;

    bool is_unlootable_from_hk(void* instance, void* container);
    inline decltype(&is_unlootable_from_hk) is_unlootable_from_o;

    bool mod_get_raid_moddable_hk(void* instance);
    inline decltype(&mod_get_raid_moddable_hk) mod_get_raid_moddable_o;

    bool mod_get_tool_moddable_hk(void* instance);
    inline decltype(&mod_get_tool_moddable_hk) mod_get_tool_moddable_o;

    void throw_grenade_hk(void* instance, eft::throwable* grenade, glm::vec3* position, glm::vec3* force, float mass);
    inline decltype(&throw_grenade_hk) throw_grenade_o;

    void client_grenade_controller_initialize_grenade_hk(void* instance, float time_since_safety_level_removed, glm::vec3* position, glm::vec4* rotation, glm::vec3* force, bool low_throw);
    inline decltype(&client_grenade_controller_initialize_grenade_hk) client_grenade_controller_initialize_grenade_o;

    bool client_grenade_controller_can_throw_hk(void* instance);
    inline decltype(&client_grenade_controller_can_throw_hk) client_grenade_controller_can_throw_o;

    void visor_effect_on_render_image_hk(bsg::camera_effects::visor_effect*, void*, void*);
    inline decltype(&visor_effect_on_render_image_hk) visor_effect_on_render_image_o;

    void procedural_weapon_animation_shot_hk(eft::animations::procedural_weapon_animation*, float);
    inline decltype(&procedural_weapon_animation_shot_hk) procedural_weapon_animation_shot_o;

    glm::vec2 stationary_weapon_get_pitch_limit_hk(void* instance);
    inline decltype(&stationary_weapon_get_pitch_limit_hk) stationary_weapon_get_pitch_limit_o;

    glm::vec2 stationary_weapon_get_yaw_limit_hk(void* instance);
    inline decltype(&stationary_weapon_get_yaw_limit_hk) stationary_weapon_get_yaw_limit_o;

    bool inventory_controller_is_at_bindable_place_hk(eft::inventory_controller* instance, eft::inventory_logic::item* item);
    inline decltype(&inventory_controller_is_at_bindable_place_hk) inventory_controller_is_at_bindable_place_o;

    bool inventory_controller_is_at_reachable_place_hk(eft::inventory_controller* instance, eft::inventory_logic::item* item);
    inline decltype(&inventory_controller_is_at_reachable_place_hk) inventory_controller_is_at_reachable_place_o;

    void* item_container_get_missing_vital_parts_hk(void* instance);
    inline decltype(&item_container_get_missing_vital_parts_hk) item_container_get_missing_vital_parts_o;

    void* item_container_get_vital_parts_hk(void* instance);
    inline decltype(&item_container_get_vital_parts_hk) item_container_get_vital_parts_o;

    void set_locked_hk(void* instance, dotnet::collections::generic::key_value_pair_2<int32_t, dotnet::string*> locked_state, void* item);
    inline decltype(&set_locked_hk) set_locked_o;

    void* get_locked_state_hk(void* instance, eft::inventory_logic::slot* slot);
    inline decltype(&get_locked_state_hk) get_locked_state_o;

    void* equipment_get_prioritized_grids_for_unloaded_object_hk(void* equipment, bool backpack_included);
    inline decltype(&equipment_get_prioritized_grids_for_unloaded_object_hk) equipment_get_prioritized_grids_for_unloaded_object_o;

    eft::next_observed_player::observed_player_view* observed_player_view_create_hk(int player_id, eft::network::observed_player_spawn_message message);
    inline decltype(&observed_player_view_create_hk) observed_player_view_create_o;

    void observed_player_view_dispose_hk(eft::next_observed_player::observed_player_view* instance);
    inline decltype(&observed_player_view_dispose_hk) observed_player_view_dispose_o;

    void game_world_register_loot_hk(void* instance, eft::interactive::loot_item* loot_item);
    inline decltype(&game_world_register_loot_hk) game_world_register_loot_o;

    void game_world_destroy_loot_hk(void* instance, eft::interactive::loot_item* loot_item);
    inline decltype(&game_world_destroy_loot_hk) game_world_destroy_loot_o;

    eft::interactive::loot_item* loot_item_init_hk(void* instance, eft::inventory_logic::item* item, dotnet::string* item_name, eft::game_world* game_world, bool random_rotation, dotnet::array<dotnet::string*>* valid_profiles, dotnet::string* static_id, bool perform_pick_up_validation);
    inline decltype(&loot_item_init_hk) loot_item_init_o;

    bool door_is_breach_angle_hk(void* instance, glm::vec3 your_position);
    inline decltype(&door_is_breach_angle_hk) door_is_breach_angle_o;

    void game_world_register_player_hk(void* instance, eft::player* player);
    inline decltype(&game_world_register_player_hk) game_world_register_player_o;

    void game_world_unregister_player_hk(void* instance, eft::player* player);
    inline decltype(&game_world_unregister_player_hk) game_world_unregister_player_o;

    int32_t random_range_int_hk(int32_t min, int32_t max);
    inline decltype(&random_range_int_hk) random_range_int_o;

    float ballistics_calculator_get_ammo_penetration_power_hk(eft::inventory_logic::ammo* ammo, int32_t seed, void* random_num_gen);
    inline decltype(&ballistics_calculator_get_ammo_penetration_power_hk) ballistics_calculator_get_ammo_penetration_power_o;

    bool is_waiting_for_network_callback_hk(void*);
    inline decltype(&is_waiting_for_network_callback_hk) is_waiting_for_network_callback_o;

    bool rtt_enabled_hk();
    inline decltype(&rtt_enabled_hk) rtt_enabled_o;

    uint64_t local_index_hk(void* instance);
    inline decltype(&local_index_hk) local_index_o;

    int32_t network_transport_get_current_rtt_hk(int32_t host_id, int32_t connection_id, uint8_t* error);
    inline decltype(&network_transport_get_current_rtt_hk) network_transport_get_current_rtt_o;

    int32_t network_transport_get_outgoing_packet_network_loss_percent_hk(int32_t hostId, int32_t connectionId, uint8_t* error);
    inline decltype(&network_transport_get_outgoing_packet_network_loss_percent_hk) network_transport_get_outgoing_packet_network_loss_percent_o;

    bool has_important_data_hk(void* instance);
    inline decltype(&has_important_data_hk) has_important_data_o;

    void* inventory_controller_get_next_discovery_time_hk(float, bool);
    inline decltype(&inventory_controller_get_next_discovery_time_hk) inventory_controller_get_next_discovery_time_o;

    void* inventory_controller_search_hk(void*, bool);
    inline decltype(&inventory_controller_search_hk) inventory_controller_search_o;

    void debug_log_handler_log_exception_hk(void* instance, void* exception, void* context);
    inline decltype(&debug_log_handler_log_exception_hk) debug_log_handler_log_exception_o;

    int32_t get_detail_height_hk(void* instance);
    inline decltype(&get_detail_height_hk) get_detail_height_o;

    void terrain_ballistic_awake_hk(void* instance);
    inline decltype(&terrain_ballistic_awake_hk) terrain_ballistic_awake_o;

    void on_trigger_enter_hk(void* instance, void* other);
    inline decltype(&on_trigger_enter_hk) on_trigger_enter_o;

    void kill_list_victim_show_hk(void* instance, void* victim_stats, bool known_name, int32_t number);
    inline decltype(&kill_list_victim_show_hk) kill_list_victim_show_o;

    void parse_mine_explosion_data_hk(void* instance, void* data);
    inline decltype(&parse_mine_explosion_data_hk) parse_mine_explosion_data_o;

    void apply_gravity_hk(eft::movement_context* instance, glm::vec3& motion, float delta_time, bool stick_to_ground);
    inline decltype(&apply_gravity_hk) apply_gravity_o;

    bool movement_context_ground_collision_raycast_hk(eft::movement_context* instance, unity_engine::ray ray, float ground_distance, float addition_search, float delta_time, unity_engine::raycast_hit* ground_hit);
    inline decltype(&movement_context_ground_collision_raycast_hk) movement_context_ground_collision_raycast_o;

    bool can_roll_hk(eft::movement_context* instance, int32_t direction, glm::vec3 shift, glm::vec3 size);
    inline decltype(&can_roll_hk) can_roll_o;

    eft::movement_state* get_current_state_hk(eft::movement_context* instance);
    inline decltype(&get_current_state_hk) get_current_state_o;

    glm::vec2 get_rotation_hk(eft::movement_context* instance);
    inline decltype(&get_rotation_hk) get_rotation_o;

    void set_blind_fire_hk(eft::movement_context* instance, int32_t blind_fire);
    inline decltype(&set_blind_fire_hk) set_blind_fire_o;

    int64_t shader_keyword_data_create_hk(void* instance, void* name, uint32_t type);
    inline decltype(&shader_keyword_data_create_hk) shader_keyword_data_create_o;

    void handle_window_resize_hk(void* instance, int width, int height, bool wasMinimized);
    inline decltype(&handle_window_resize_hk) handle_window_resize_o;

    dotnet::string* key_component_get_id_hk(void* instance);
    inline decltype(&key_component_get_id_hk) key_component_get_id_o;

    bool is_streamer_mode_active_hk(void* instance);
    inline decltype(&is_streamer_mode_active_hk) is_streamer_mode_active_o;

    bool is_local_streamer_hk(void* instance, dotnet::string* id);
    inline decltype(&is_local_streamer_hk) is_local_streamer_o;

    void movement_info_packet_constructor_hk(void* instance, eft::e_player_state e_player_state, int32_t animator_state_index, float pose_level, float character_movement_speed, float tilt, int32_t step, int32_t blind_fire, void* interact_with_door_packet, void* loot_interaction_packet, void* stationary_weapon_packet, void* plant_item_packet, bool soft_surface, glm::vec3 head_rotation, void* stamina, bool sync_position_applied, int32_t discrete_movement_direction, bool is_grounded, glm::vec3 surface_normal, glm::vec3 player_surface_up_align_normal);
    inline decltype(&movement_info_packet_constructor_hk) movement_info_packet_constructor_o;

    void grenade_late_update_hk(eft::grenade* instance);
    inline decltype(&grenade_late_update_hk) grenade_late_update_o;

    float weapon_get_current_overheat_hk(eft::inventory_logic::weapon* instance, float past_time, void* overheat_settings, float* mods_cool_factor);
    inline decltype(&weapon_get_current_overheat_hk) weapon_get_current_overheat_o;

    glm::vec3 get_imitator_position_local_hk(void* instance, glm::vec3 relative_point);
    inline decltype(&get_imitator_position_local_hk) get_imitator_position_local_o;

    void set_tilt_hk(eft::movement_context* instance, float tilt, bool force);
    inline decltype(&set_tilt_hk) set_tilt_o;

    int32_t armor_component_get_speed_penalty_hk(void* instance);
    inline decltype(&armor_component_get_speed_penalty_hk) armor_component_get_speed_penalty_o;

    int32_t armor_component_get_mouse_penalty_hk(void* instance);
    inline decltype(&armor_component_get_mouse_penalty_hk) armor_component_get_mouse_penalty_o;

    eft::inventory_logic::e_deaf_strength armor_component_get_deaf_hk(void* instance);
    inline decltype(&armor_component_get_deaf_hk) armor_component_get_deaf_o;

    void add_state_speed_limit_hk(eft::movement_context* instance, float speed_limit, eft::player_e_speed_limit cause);
    inline decltype(&add_state_speed_limit_hk) add_state_speed_limit_o;

    bool set_pose_level_hk(eft::movement_context* instance, float pose_level, bool force);
    inline decltype(&set_pose_level_hk) set_pose_level_o;

    eft::e_physical_condition obstacle_collider_get_conditions_mask_hk(void* instance);
    inline decltype(&obstacle_collider_get_conditions_mask_hk) obstacle_collider_get_conditions_mask_o;

    void* magazine_get_ammo_count_by_level_hk(void* instance, int32_t ammo_count, int32_t max_ammo_count, int32_t skill, void* color, bool checked, bool item_in_hands, void* value_format);
    inline decltype(&magazine_get_ammo_count_by_level_hk) magazine_get_ammo_count_by_level_o;

    void shot_reactions_hk(eft::player* player, void* shot, eft::e_body_part body_part);
    inline decltype(&shot_reactions_hk) shot_reactions_o;

    void effects_controller_on_damage_received_hk(void* instance, float damage, eft::e_body_part bodyPart, eft::e_damage_type type, float damage_reduced_by_armor, int32_t special);
    inline decltype(&effects_controller_on_damage_received_hk) effects_controller_on_damage_received_o;

    void effects_controller_on_burn_eyes_hk(void* instance, glm::vec3 position, float str, float time);
    inline decltype(&effects_controller_on_burn_eyes_hk) effects_controller_on_burn_eyes_o;

    void effects_controller_add_effect_hk(void* instance, void* effect);
    inline decltype(&effects_controller_add_effect_hk) effects_controller_add_effect_o;

    void effects_controller_update_hk(void* instance);
    inline decltype(&effects_controller_update_hk) effects_controller_update_o;

    void camera_manager_blur_hk(void* instance, bool is_active, float time);
    inline decltype(&camera_manager_blur_hk) camera_manager_blur_o;

    float health_effects_component_use_time_for_hk(void* instance, eft::e_body_part body_part);
    inline decltype(&health_effects_component_use_time_for_hk) health_effects_component_use_time_for_o;

    void movement_context_manual_update_hk(eft::movement_context* instance, float delta_time);
    inline decltype(&movement_context_manual_update_hk) movement_context_manual_update_o;

    void* weapon_get_mods_hk(eft::inventory_logic::item* instance);
    inline decltype(&weapon_get_mods_hk) weapon_get_mods_o;

    bool health_treatment_screen_is_available_hk(void* profile, void* health_controller, void* trader);
    inline decltype(&health_treatment_screen_is_available_hk) health_treatment_screen_is_available_o;

    void* item_ui_context_show_invite_in_group_window_hk(void* instance, void* group_invite);
    inline decltype(&item_ui_context_show_invite_in_group_window_hk) item_ui_context_show_invite_in_group_window_o;

    bool player_within_hearing_distance_hk(glm::vec3 voice_pos, float sqr_distance);
    inline decltype(&player_within_hearing_distance_hk) player_within_hearing_distance_o;

    unity_engine::ray player_interaction_ray_hk(eft::player* instance);
    inline decltype(&player_interaction_ray_hk) player_interaction_ray_o;

    bool physical_get_sprinting_hk(void* instance);
    inline decltype(&physical_get_sprinting_hk) physical_get_sprinting_o;

    void match_maker_selection_location_screen_show_hk(eft::ui::matchmaker::match_maker_selection_location_screen* instance, eft::network::i_session* session, eft::raid_settings* raid_settings);
    inline decltype(&match_maker_selection_location_screen_show_hk) match_maker_selection_location_screen_show_o;

    void form_trajectory_hk(glm::vec3 zero_position, glm::vec3 zero_velocity, float bullet_mass_gram, float bullet_diameter_milimeters, float ballistic_coefficient, void* trajectory_info);
    inline decltype(&form_trajectory_hk) form_trajectory_o;

    void cursor_visibility_changed_hk(bool is_cursor_visible);
    inline decltype(&cursor_visibility_changed_hk) cursor_visibility_changed_o;

    dotnet::string* get_stack_trace_hk(void* exception, bool need_file_info);
    inline decltype(&get_stack_trace_hk) get_stack_trace_o;

    bool is_log_type_allowed_hk(void* instance, int32_t log_type);
    inline decltype(&is_log_type_allowed_hk) is_log_type_allowed_o;

    bool get_log_enabled_hk(void* instance);
    inline decltype(&get_log_enabled_hk) get_log_enabled_o;

    dotnet::array<void*>* get_trace_hk(void* e, int32_t skip_frames, bool f_need_file_info);
    inline decltype(&get_trace_hk) get_trace_o;

    void process_effectors_hk(eft::animations::procedural_weapon_animation* instance, float delta_time, int32_t n_fixed_frames, glm::vec3 motion, glm::vec3 velocity);
    inline decltype(&process_effectors_hk) process_effectors_o;

    void avoid_obstacles_hk(eft::animations::procedural_weapon_animation* instance);
    inline decltype(&avoid_obstacles_hk) avoid_obstacles_o;

    bool can_move_hk(void* instance);
    inline decltype(&can_move_hk) can_move_o;

    void ballistic_update_hk(eft::player_firearm_controller* instance, float delta_time);
    inline decltype(&ballistic_update_hk) ballistic_update_o;

    int current_mastering_level_hk(eft::player_firearm_controller* instance);
    inline decltype(&current_mastering_level_hk) current_mastering_level_o;

    void physical_controller_late_update_hk(eft::physical_controller* instance);
    inline decltype(&physical_controller_late_update_hk) physical_controller_late_update_o;

    void interaction_raycast_hk(eft::player* instance);
    inline decltype(&interaction_raycast_hk) interaction_raycast_o;

    void complex_update_hk(eft::player* instance, int32_t queue, float delta_time);
    inline decltype(&complex_update_hk) complex_update_o;

    void* player_apply_shot_hk(eft::player* instance, eft::damage_info* damage_info, eft::e_body_part body_part_type, int32_t collider_type, int32_t armor_plate_collider, void* shot_id);
    inline decltype(&player_apply_shot_hk) player_apply_shot_o;

    void setup_item_hk(eft::player_player_inventory_controller* instance, eft::inventory_logic::item* item, dotnet::string* zone, glm::vec3 position, glm::vec4 rotation, float setup_time, comfort::common::callback* callback);
    inline decltype(&setup_item_hk) setup_item_o;

    void jump_movement_state_enter_hk(eft::jump_movement_state* instance, bool is_from_same_state);
    inline decltype(&jump_movement_state_enter_hk) jump_movement_state_enter_o;

    void start_tinnitus_effect_hk(void* instance, float time, void* clip);
    inline decltype(&start_tinnitus_effect_hk) start_tinnitus_effect_o;

    bool get_breath_is_audible_hk(eft::physical_controller* instance);
    inline decltype(&get_breath_is_audible_hk) get_breath_is_audible_o;

    void* get_metrics_hk(void* instance);
    inline decltype(&get_metrics_hk) get_metrics_o;
#if 0
    void data_handler_hk(void* instance, eft::network::body_health_data data);
    inline decltype(&data_handler_hk) data_handler_o;

    void apply_damage_info_hk(eft::player* instance, eft::damage_info* damage_info, int32_t body_part_type, float absorbed, sdk::nullable<int32_t> head_segment);
    inline decltype(&apply_damage_info_hk) apply_damage_info_o;
#endif
    void player_animator_update_layers_hk(eft::next_observed_player::observed_player_view* instance, eft::wild_spawn_type role);
    inline decltype(&player_animator_update_layers_hk) player_animator_update_layers_o;

    void reaction_on_shot_hk(eft::next_observed_player::observed_player_view* instance, eft::damage_info* shot, eft::e_body_part body_part);
    inline decltype(&reaction_on_shot_hk) reaction_on_shot_o;

    void movement_context_flash_hk(eft::movement_context* instance, glm::vec3& motion);
    inline decltype(&movement_context_flash_hk) movement_context_flash_o;

    void movement_context_direct_apply_motion_hk(eft::movement_context* instance, glm::vec3 motion, float delta_time);
    inline decltype(&movement_context_direct_apply_motion_hk) movement_context_direct_apply_motion_o;

    void create_speed_limiter_hk(eft::movement_context* instance, void* config);
    inline decltype(&create_speed_limiter_hk) create_speed_limiter_o;

    void set_character_movement_speed_hk(eft::movement_context* instance, float character_movement_speed, bool force);
    inline decltype(&set_character_movement_speed_hk) set_character_movement_speed_o;

    void send_client_2_server_packet_hk(void* instance, void* client_2_server_packet, float delta_time, float time, float last_server_time);
    inline decltype(&send_client_2_server_packet_hk) send_client_2_server_packet_o;

    float gameworld_get_delta_time_hk(eft::game_world* instance);
    inline decltype(&gameworld_get_delta_time_hk) gameworld_get_delta_time_o;

    bool is_group_full_hk(void* instance);
    inline decltype(&is_group_full_hk) is_group_full_o;

    bool get_coop_available_for_group_hk(void* instance);
    inline decltype(&get_coop_available_for_group_hk) get_coop_available_for_group_o;

    bool is_coop_allowed_hk(void* instance, dotnet::string* game_version);
    inline decltype(&is_coop_allowed_hk) is_coop_allowed_o;

    bool get_has_access_to_coop_hk(void* instance);
    inline decltype(&get_has_access_to_coop_hk) get_has_access_to_coop_o;

    void get_player_profile_callback_hk(void* instance, comfort::common::result_1<eft::network::other_player_profile*> result);
    inline decltype(&get_player_profile_callback_hk) get_player_profile_callback_o;

    void tod_sky_late_update_hk(tod::tod_sky* instance);
    inline decltype(&tod_sky_late_update_hk) tod_sky_late_update_o;

    bool eft_hard_settings_can_aim_in_state_hk(void* instance, eft::e_player_state current_state_name);
    inline decltype(&eft_hard_settings_can_aim_in_state_hk) eft_hard_settings_can_aim_in_state_o;

    bool operation_handler_can_execute_hk(void* instance, eft::network::operation_result operation_result);
    inline decltype(&operation_handler_can_execute_hk) operation_handler_can_execute_o;
} // namespace hooks

#endif