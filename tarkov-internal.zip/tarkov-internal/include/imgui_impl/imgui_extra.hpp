#ifndef IMGUI_IMPL_IMGUI_EXTRA_HPP
#define IMGUI_IMPL_IMGUI_EXTRA_HPP

#define IMGUI_DEFINE_MATH_OPERATORS

#include <imgui_internal.h>
#include <imgui.h>

#include <stack>

#include <cmath>
#include <functional>
#include <glm/vec2.hpp>
#include <mutex>

#include <renderer/color.hpp>

namespace ImGui {
    bool ListBox(const char* label, int32_t* current_item, std::function<const char* (int32_t)> pLambda, int32_t items_count, int32_t height_in_items);
    void HelpMarker(const char* desc);
    bool Hotkey(const char* label, int32_t* k);

    template <typename T>
    T round_to_step (T value, T step) {
       return (((T)std::round(value / step)) * step);
    }
}

#endif