#ifndef GLOBALS_HPP
#define GLOBALS_HPP

#include <bitset>
#include <future>
#include <shared_mutex>
#include <unordered_map>

#include "custom_structs.hpp"

// Forward declarations
namespace features {
    class physics_simulation;
}

namespace eft {
    class game_world;
    class tarkov_application;
    class player;
    class level_settings;
    class player_item_hands_controller;
    namespace camera_control {
        class camera_manager;
        class optic_camera_manager;
    }
    namespace counters {
        class counter_hash_table;
        class counter;
    }
    namespace network {
        class network_game;
    }
    namespace quests {
        class quest_template_manager;
    }
    namespace ui {
        enum class eft_screen_type : int32_t;
        enum class e_visibility_mode : int32_t;
    }
    enum class e_player_state : uint8_t;
}

namespace unity_engine {
    class camera;
    class asset_bundle;
    class shader;
    class material;
    class audio_source;
}

namespace mono {
    struct mono_class;
    struct mono_object;
}

namespace renderer {
    class d3d11_renderer;
    class buffer;
    class text_font;
}

namespace shaders {
    // Store all shader properties here and shader pointers
    // A wrapper to easily create shaders, and set property isn't worth the time
}

struct ImFont;
namespace game {
    constexpr auto PLAYER_TIMER_THRESHOLD = 1.0f;
    constexpr auto LOOT_TIMER_THRESHOLD = 3.0f;
    constexpr auto QUEST_TIMER_THRESHOLD = 5.0f;
    constexpr auto PLAYER_DATA_TIMER_THRESHOLD = 5.0f;
    constexpr auto CHAMS_TIMER_THRESHOLD = 3.0f;
    constexpr auto MAX_DISTANCE = 10000.0f;
    constexpr bool disable_risky_features = true;

    constexpr int32_t HOOKED_SEED = 420;
    // Modules
    extern uint64_t hmodule;
    extern uint64_t base;
    extern uint64_t unity_player;
    extern uint64_t mono;
    extern std::future<bool> market_future;
    extern mono::mono_class* target_class_;
    extern unity_engine::material* draw_material_;

    // Assets
    extern unity_engine::asset_bundle* bundle;

    // Cham materials
    extern unity_engine::shader* wireframe_shader;
    extern unity_engine::shader* rim_shader;
    extern unity_engine::shader* flat_shader;
    extern unity_engine::audio_source* audio_source;
    extern unity_engine::audio_clip* hit_marker_audio_clip;
    extern int32_t chams_color_visible_id;
    extern int32_t chams_color_behind_id;

    extern std::atomic<eft::game_world*> game_world;
    extern std::atomic<eft::tarkov_application*> tarkov_application;
    extern std::atomic<unity_engine::camera*> camera;
    extern std::atomic<unity_engine::camera*> optic_camera;
    extern std::atomic<unity_engine::camera*> active_camera;
    extern std::atomic<eft::camera_control::camera_manager*> camera_manager;
    //extern eft::camera_control::optic_camera_manager* optic_camera_manager;

    // Exploit states
    extern std::atomic<bool> exploiting_take_action;
    extern std::atomic<bool> wants_click_tp;
    extern std::shared_ptr<game::cached_player> local_player;
    extern std::atomic<eft::level_settings*> level_settings;
    extern std::atomic<eft::network::network_game*> network_game;
    extern std::atomic<eft::quests::quest_template_manager*> quest_template_manager;

    extern std::shared_ptr<target_info> target;
    extern std::unique_ptr<player_held_item_info> local_player_held_item_info;

    extern std::shared_mutex tracers_mutex;
    extern std::shared_mutex hit_marker_mutex;
    extern std::shared_mutex trajectory_mutex;
    extern std::shared_mutex loot_mutex;
    extern std::shared_mutex loot_int_mutex;
    extern std::shared_mutex players_mutex;
    extern std::shared_mutex players_data_mutex;
    extern std::shared_mutex players_profile_info_mutex;
    extern std::shared_mutex players_int_mutex;
    extern std::shared_mutex target_mutex;
    extern std::shared_mutex stats_mutex;

    extern std::shared_mutex quests_locations_mutex;
    extern std::shared_mutex quests_items_mutex;

    extern std::list<game::tracer> tracers;
    extern std::list<game::hit_record> hit_records;
    extern std::list<eft::ballistics::trajectory_info> trajectory;

    extern std::vector<std::shared_ptr<game::cached_player>> cached_players;
    extern std::unordered_map<std::wstring, game::cached_player_data> cached_players_data;
    extern std::unordered_map<std::wstring, game::cached_player_profile_info> cached_players_profile_info;
    extern std::vector<game::cached_loot_item> cached_items;
    extern std::vector<game::cached_container> cached_containers;
    extern std::vector<game::cached_corpse> cached_corpses;

    extern std::vector<game::cached_quest> cached_quests;
    extern std::vector<std::wstring> cached_quest_item_ids;

    extern std::unordered_map<std::wstring, eft::counters::counter*> counter_list;
    extern std::unordered_map<std::wstring, std::unique_ptr<std::unordered_map<std::wstring, double>>> player_stats;

    extern std::unordered_map<std::wstring, glm::vec3> cached_quest_zone_locations;
    extern std::vector<std::pair<std::wstring, glm::vec3>> quest_objects;
    extern std::vector<std::pair<std::wstring, uint32_t>> quest_not_found_objects;

    extern std::wstring current_profile_id;

    extern std::atomic<bool> market_success;
    extern std::atomic<bool> unloading;

    extern std::atomic<eft::ui::eft_screen_type> current_screen;
    extern std::atomic<float> fov;
    extern std::atomic<float> time;
    extern std::wstring in_game_time;
    extern std::atomic<float> fps;
    extern std::atomic<float> world_north;
    extern std::atomic<glm::vec2> screen_size;
    extern std::atomic<float> loot_timer;
    extern std::atomic<float> quest_timer;
    extern std::atomic<float> chams_timer;
    extern std::atomic<float> player_data_timer;
    extern std::atomic<float> player_timer;

    extern std::bitset<32> item_filter;

    extern std::wstring target_map;
    extern std::vector<std::pair<std::wstring, std::wstring>> tarkov_locations;

    extern unity_engine::component* target_class_component_;

    inline glm::vec2 networked_rotation{};

    // Physics prediction
    extern std::shared_mutex simulation_mutex;
    extern std::unique_ptr<features::physics_simulation> simulation;
}

namespace visuals {
    extern bool initialized_renderer;
    extern std::unique_ptr<renderer::d3d11_renderer> dx11;

    extern size_t visual2d_buf_id;
    extern size_t visual3d_buf_id;
    extern size_t visual3d_lines_buf_id;
    extern size_t ui_buf_id;

    extern renderer::buffer* buf2d;
    extern renderer::buffer* buf3d;
    extern renderer::buffer* buf3d_lines;
    extern renderer::buffer* ui_buffer;

    extern float normal_font_size;

    // TODO: Add Visitor TT2 BRK or 04B03
    extern renderer::text_font* segoe_ui_font;
    extern renderer::text_font* smallest_ui_font;
    extern renderer::text_font* tahoma_font;

    extern ImFont* normal_font;

    extern float dpi_scale_factor;
    extern glm::vec2 window_size;
    extern glm::vec2 center_screen;
}

#endif