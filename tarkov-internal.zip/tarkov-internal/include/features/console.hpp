#ifndef FEATURES_CONSOLE_HPP
#define FEATURES_CONSOLE_HPP

#include <renderer/font.hpp>
#include <renderer/color.hpp>

#include <memory>
#include <string>
#include <vector>

#include "sdk.hpp"

namespace renderer {
    class text_font;
}

namespace logger {
    // TODO: Escape sequence multicolor console text entries
    class console {
    public:
        void set_font(renderer::text_font* font);

        template <typename string_t>
        void add(const string_t& text, const renderer::color_rgba& color = COLOR_WHITE, float time = 8.f) {
            add(std::basic_string_view(text), color, time);
        }

        template <typename char_t>
        void add(std::basic_string_view<char_t> text, const renderer::color_rgba& color = COLOR_WHITE, float time = 8.f) {
            if (font_ == nullptr)
                return;

            if constexpr (std::is_same_v<char_t, char>) {
                entries_.push_back(std::make_unique<string_entry>(std::string {text}, color, unity_engine::time::get_time_prop() + time, font_->calc_text_size(text)));
            } else if constexpr (std::is_same_v<char_t, wchar_t>) {
                entries_.push_back(std::make_unique<wstring_entry>(std::wstring {text}, color, unity_engine::time::get_time_prop() + time, font_->calc_text_size(text)));
            }
        }

        void render();

    private:
        class abstract_entry {
        public:
            abstract_entry(const renderer::color_rgba& color, float time, glm::vec2 text_size) : color(color), time(time), text_size(text_size) {}
            virtual void render(renderer::text_font* font, glm::vec2 position, uint8_t override_alpha) = 0;

            renderer::color_rgba color;
            float time;
            glm::vec2 text_size;
        };

        class string_entry : public abstract_entry {
        public:
            string_entry(std::basic_string_view<char> text, const renderer::color_rgba& color, float time, glm::vec2 text_size) : abstract_entry(color, time, text_size), text {text} {}
            void render(renderer::text_font* font, glm::vec2 position, uint8_t override_alpha) override;

            std::string text;
        };

        class wstring_entry : public abstract_entry {
        public:
            wstring_entry(std::basic_string_view<wchar_t> text, const renderer::color_rgba& color, float time, glm::vec2 text_size) : abstract_entry(color, time, text_size), text {text} {}
            void render(renderer::text_font* font, glm::vec2 position, uint8_t override_alpha) override;

            std::wstring text;
        };

        renderer::text_font* font_;
        std::vector<std::unique_ptr<abstract_entry>> entries_;
    };
} // namespace logger

#endif