#ifndef FEATURES_PHYSICS_SIMULATION_HPP
#define FEATURES_PHYSICS_SIMULATION_HPP

#include "sdk.hpp"

namespace features {
    // Engine prediction simulator using dedicated 3d prediction scene
    // TODO: Look into ThrowGrenadePlace for automatic grenade throwing
    class physics_simulation {
    public:
        bool is_valid();

        void create_physics_scene();
        void unload_physics_scene();

        void set_iterations(size_t iterations);
        void set_fixed_delta_time(float fixed_dt);
        void set_time_limit(float time_limit);

        void copy_move_game_object_to_scene(unity_engine::game_object* game_object, float time_limit = 0.0f);
        std::vector<std::pair<unity_engine::game_object*, std::vector<glm::vec3>>> simulate_all_objects();
        void destroy_dummy_objects();

    private:
        unity_engine::scene_management::scene scene_ {};
        unity_engine::physics_scene physics_scene_ {};

        size_t iterations_ {};
        float fixed_dt_ {};
        float time_limit_ {};

        std::vector<std::pair<unity_engine::game_object*, float>> dummy_objects_ {};
    };

    struct predicted_grenade {
        eft::grenade* grenade;
        std::vector<glm::vec3> positions;
    };

    // TODO: Hook Register and Unregister Grenade to then cache grenade predicted positions
    inline std::unordered_map<int32_t, predicted_grenade> predicted_grenades {};
} // namespace features

#endif