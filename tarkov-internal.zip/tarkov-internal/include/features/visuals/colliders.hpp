#ifndef FEATURES_VISUALS_COLLIDERS_HPP
#define FEATURES_VISUALS_COLLIDERS_HPP

#include "sdk_extra/custom/iplayer.hpp"

#include <renderer/color.hpp>

// TODO: Rename this to debug or something since it's kinda used to render a lot of debug information

namespace visuals {
    void draw_wire_arc(const glm::vec3& center, const glm::vec3& normal, const glm::vec3& from, float angle, float radius, const renderer::color_rgba& color, size_t segments = 16);
    void draw_wire_disc(const glm::vec3& center, const glm::vec3& normal, float radius, const renderer::color_rgba& color, size_t segments = 16);
    void draw_wire_box(const glm::vec3& center, const glm::vec3& extents, const glm::quat& orientation, const renderer::color_rgba& color);
    void draw_wire_sphere(const glm::vec3& center, float radius, const renderer::color_rgba& color, size_t segments = 16);
    void draw_wire_capsule(const glm::vec3& p1, const glm::vec3& p2, float radius, const renderer::color_rgba& color, size_t segments = 16);
    void draw_wire_cylinder(const glm::vec3& start, const glm::vec3& end, float radius, const renderer::color_rgba& color, size_t segments = 16);

    void draw_wire_plane(const glm::vec3& position, const glm::vec3& normal, const renderer::color_rgba& color);
    void draw_wire_cone(const glm::vec3& position, const glm::vec3& direction, float angle, const renderer::color_rgba& color, size_t segments = 16);
    void draw_wire_frustum(const glm::vec3& center, float fov, float max_range, float min_range, float aspect, const renderer::color_rgba& color);

    void draw_box_collider(unity_engine::box_collider* box, const renderer::color_rgba& color);
    void draw_capsule_collider(unity_engine::capsule_collider* capsule, const renderer::color_rgba& color);
    void draw_sphere_collider(unity_engine::sphere_collider* sphere, const renderer::color_rgba& color);

    void draw_collider(unity_engine::collider* collider, const renderer::color_rgba& color);
    void draw_debug_player_colliders(eft::player_interface& iplayer);

    void draw_nav_mesh_path(unity_engine::ai::nav_mesh_path* path, const renderer::color_rgba& color, float offset_up = 0.1f);

    class collider_hit_record {
    public:
        virtual ~collider_hit_record() = default;
        collider_hit_record(const renderer::color_rgba& color);
        virtual void render() const = 0;

    protected:
        renderer::color_rgba color_;
    };

    class box_collider_hit_record : public collider_hit_record {
    public:
        box_collider_hit_record(const glm::vec3& center, const glm::vec3& extents, const glm::quat& orientation, const renderer::color_rgba& color);
        void render() const override;

    private:
        glm::vec3 center_;
        glm::vec3 extents_;
        glm::quat orientation_;
    };

    class capsule_collider_hit_record : public collider_hit_record {
    public:
        capsule_collider_hit_record(const glm::vec3& p1, const glm::vec3& p2, float radius, const renderer::color_rgba& color);
        void render() const override;

    private:
        glm::vec3 p1_;
        glm::vec3 p2_;
        float radius_;
    };

    class sphere_collider_hit_record : public collider_hit_record {
    public:
        sphere_collider_hit_record(const glm::vec3& center, float radius, const renderer::color_rgba& color);
        void render() const override;

    private:
        glm::vec3 center_;
        float radius_;
    };
}

#endif