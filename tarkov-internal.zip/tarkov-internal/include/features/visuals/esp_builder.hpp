#ifndef FEATURES_VISUALS_ESP_BUILDER_HPP
#define FEATURES_VISUALS_ESP_BUILDER_HPP

#include <glm/glm.hpp>

#include <memory>
#include <vector>

namespace renderer {
    class text_font;
}

namespace visuals {
    enum esp_component_align_side {
        component_side_left,
        component_slide_right,
        component_side_top,
        component_side_bottom,
        component_side_max
    };

    enum esp_component_align_direction {
        component_direction_left,
        component_direction_right,
        component_direction_up,
        component_direction_down,
        component_direction_max
    };

    class base_component {
    public:
        [[nodiscard]] virtual glm::vec2 get_base_position(const glm::vec4& bounds) const = 0;

        [[nodiscard]] virtual bool is_directional() const {
            return false;
        }

        virtual void draw(const glm::vec2& position) const = 0;

    protected:
        esp_component_align_side side_ = component_side_top;

        glm::vec2 offset_;
        glm::vec2 size_;
    };

    class base_directional_component : public base_component {
    public:
        [[nodiscard]] bool is_directional() const override {
            return true;
        }

    protected:
        esp_component_align_direction direction_ = component_direction_up;
    };

    class bar_component : public base_directional_component {
    private:
        float progress_ = 0.0f;
    };

    template <class char_t>
    class text_component : public base_directional_component {
    private:
        renderer::text_font* font;
        // TODO: String storage
    };

    class esp_builder_context {
    private:
        std::vector<std::unique_ptr<base_component>> components_;
        float component_spacing_ = 1.0f;
        float side_paddings[component_side_max] = {};
        float side_direction_paddings[component_side_max][component_direction_max] = {};
    };
} // namespace visuals

#endif