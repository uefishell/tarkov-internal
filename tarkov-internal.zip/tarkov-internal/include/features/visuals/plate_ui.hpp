#ifndef FEATURES_VISUALS_PLATE_UI_HPP
#define FEATURES_VISUALS_PLATE_UI_HPP

#include "game.hpp"

namespace visuals {
    class plate_ui {
    public:
        plate_ui(const eft::player_interface& player) : current_player_(player) {
            create();
        }

        void create() {
            object_->ctor((dotnet::string*)mono::string::from_string(L"PlateUI"));
            player_name_ = object_->add_component<tm_pro::text_mesh_pro_ugui>();
        }

        void destroy() {
            object_->set_active(false);
            unity_engine::object::destroy(object_);
        }

        void update_name_position() {
            const auto aa = game::camera.load()->get_game_object_prop()->get_component<ssaa>();
            if (aa != nullptr && aa->get_is_active_and_enabled_prop()) {
                screen_scale_ = aa->get_output_width() / aa->get_input_width();
            }

            const float scale = glm::clamp(glm::distance(game::camera.load()->get_transform_prop()->get_position_prop(), current_player_.player_body()->get_bone_position(eft::human_base)) / 100.0f, 0.8f, 1.2f);

            glm::vec3 position = current_player_.player_body()->get_bone_position(eft::human_neck) + glm::vec3(0.0f, 0.7f, 0.0f);
            position = game::camera.load()->world_to_screen_point(position);
            if (position.z <= 0.0f) {
                // Shouldn't render when clear
                player_name_->set_color_prop(renderer::color_rgba(0.0f, 0.0f, 0.0f, 0.0f));
            }

            const auto name_transform = player_name_->get_transform_prop();
            name_transform->set_position_prop(position * screen_scale_);
            name_transform->set_local_scale_prop(glm::vec3(1.0f, 1.0f, 1.0f) / scale);

            const auto alpha = glm::distance(position, glm::vec3(unity_engine::screen::get_width_prop(), unity_engine::screen::get_height_prop(), 0.0f) / 2.0f);
            player_name_->set_color_prop(renderer::color_rgba(1.0f, 1.0f, 1.0f, alpha >= 200 ? 255 : glm::max(0.1f, alpha / 200.0f)));
        }

    private:
        eft::player_interface current_player_;

        unity_engine::game_object* object_;
        tm_pro::text_mesh_pro_ugui* player_name_;

        // TODO: I'm being a fucking retard right now and we should use screen scale elsewhere
        float screen_scale_ = 1.0f;
    };
}

#endif