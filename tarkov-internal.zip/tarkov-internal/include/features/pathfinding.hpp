#ifndef FEATURES_PATHFINDING_HPP
#define FEATURES_PATHFINDING_HPP

#include "sdk.hpp"

namespace test {
    // Taken from BotMover::CalcPath
    dotnet::array<glm::vec3>* calc_path(const glm::vec3& from, const glm::vec3& to) {
        // TODO: Probably need to call the actual ctor
        auto nav_mesh_path = mono::object_new<unity_engine::ai::nav_mesh_path>();
        if (unity_engine::ai::nav_mesh::calculate_path(from, to, -1, nav_mesh_path)) {
            return nav_mesh_path->get_corners();
        }

        //unity_engine::ai::nav_mesh_hit nav_mesh_hit;
        //if (unity_engine::ai::nav_mesh::sample_position(from, &nav_mesh_hit, 7.0f, -1) {
        //    return nav_mesh_path->get_corners();
        //}

        return nullptr;
    }

    float calculate_path_length(dotnet::array<glm::vec3>* corners) {
        if (corners == nullptr) {
            return std::numeric_limits<float>::max();
        }

        if (corners->size() < 2) {
            return 0.0f;
        }

        float distance = 0.0f;

        glm::vec3 prev = corners->get(0);
        for (size_t i = 1; i < corners->size(); i++) {
            const auto& current = corners->get(i);
            distance += glm::distance(prev, current);
            prev = current;
        }

        return distance;
    }

    void move_to(eft::player* player, const glm::vec3& to, float dest_move_speed = 1.0f) {
        const auto from = player->get_transform_prop()->get_position_prop();

        auto path = calc_path(from, from);
        glm::vec3 target = to;

        if (path != nullptr && path->get_length() >= 2) {
            target = path->get(1);
        }

        const auto direction = from - target;
        const auto normal_direction = glm::normalize(direction);

        // TODO: If near door set dest speed to 0.5f
        const auto speed_delta = dest_move_speed - player->get_speed_prop();
        if (glm::abs(speed_delta) > std::numeric_limits<float>::epsilon()) {
            player->change_speed(speed_delta)
        }

        // Should just be able to do player->move(dir)
    }
}

#endif