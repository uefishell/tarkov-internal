#ifndef FEATURES_VISUALS_HPP
#define FEATURES_VISUALS_HPP

#include <renderer/buffer.hpp>
#include <renderer/renderer.hpp>

#include "game.hpp"

#include "visuals/plate_ui.hpp"
#include "pathfinding.hpp"

namespace visuals {
    // TODO: Move this to globals
    extern glm::mat4x4 game_projection;

    void loot();
    void world();
    void players();
} // namespace visuals

#endif