#ifndef FEATURES_FEATURES_HPP
#define FEATURES_FEATURES_HPP

#include "globals.hpp"
#include "sdk.hpp"

namespace features {
    void aimbot();
    void targeting();
    void misc();
    void visuals();

    void apply_player_hit(eft::player_interface player, eft::damage_info* shot, eft::e_body_part body_part);
} // namespace features

#endif