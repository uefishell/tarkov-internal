#ifndef INPUT_HPP
#define INPUT_HPP

#include <glm/glm.hpp>
#include <Windows.h>

namespace input {
    // Call at the end of where we check all input interactions
    void input_end();

    [[nodiscard]] glm::vec2 get_mouse_pos();

    [[nodiscard]] bool is_key_down(uint32_t key);
    [[nodiscard]] bool is_key_pressed(uint32_t key);
    [[nodiscard]] bool is_key_released(uint32_t key);
    [[nodiscard]] uint32_t get_last_key_down();

    LRESULT handler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
}

#endif